import React from 'react';
import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-8 bg-white">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-4">梗图模板生成器</h1>
        <p className="text-xl mb-8">
          创建你自己的"Starter Pack Meme"，添加图片、文字，然后分享给朋友。
        </p>
        <p className="mb-8 text-gray-600">
          简单选择布局，上传图片，添加文字，生成你的专属梗图。
        </p>
        <Link 
          href="/create" 
          className="px-8 py-3 bg-black text-white rounded-md font-medium text-lg hover:bg-gray-800 transition-colors"
        >
          立即制作
        </Link>
      </div>
    </main>
  );
} 