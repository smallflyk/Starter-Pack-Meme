import React from 'react';
import MemeEditor from '../components/MemeEditor';

export default function CreatePage() {
  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold text-center mb-8">创建你的 Starter Pack Meme</h1>
      <MemeEditor />
    </div>
  );
} 