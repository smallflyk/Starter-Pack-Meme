'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import html2canvas from 'html2canvas';

interface MemeData {
  id: string;
  title: string;
  imageUrl: string;
}

export default function MemePage() {
  const params = useParams();
  const id = params.id as string;
  const [meme, setMeme] = useState<MemeData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // 从localStorage获取梗图数据
    const fetchMeme = () => {
      setLoading(true);
      try {
        const memesData = localStorage.getItem('memes') 
          ? JSON.parse(localStorage.getItem('memes') || '{}') 
          : {};
        
        const memeData = memesData[id];
        
        if (memeData) {
          setMeme(memeData);
        }
      } catch (error) {
        console.error('获取梗图失败', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchMeme();
    }
  }, [id]);

  const downloadMeme = () => {
    if (!meme?.imageUrl) return;
    
    const link = document.createElement('a');
    link.href = meme.imageUrl;
    link.download = `${meme.title.replace(/\s+/g, '-').toLowerCase() || 'starter-pack'}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl">加载中...</p>
      </div>
    );
  }

  if (!meme) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8">
        <h1 className="text-2xl font-bold mb-4">梗图未找到</h1>
        <p className="mb-8">无法找到这个梗图，它可能已被删除或不存在。</p>
        <Link 
          href="/" 
          className="px-6 py-2 bg-black text-white rounded-md hover:bg-gray-800"
        >
          返回首页
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-3xl mx-auto p-6 bg-white shadow-lg rounded-lg">
        <h1 className="text-3xl font-bold text-center mb-6">{meme.title}</h1>
        
        <div className="mb-8 border-2 border-black p-2">
          <img 
            src={meme.imageUrl} 
            alt={meme.title} 
            className="w-full h-auto"
          />
        </div>
        
        <div className="flex justify-center space-x-4">
          <button
            onClick={downloadMeme}
            className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            下载梗图
          </button>
          <Link
            href="/"
            className="px-6 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
          >
            返回首页
          </Link>
        </div>
      </div>
    </div>
  );
} 