'use client';

import React, { useState, useRef, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import html2canvas from 'html2canvas';
import { useRouter } from 'next/navigation';
import ImageUploader from './ImageUploader';

interface GridItem {
  id: string;
  imageUrl: string | null;
}

interface MemeData {
  id: string;
  title: string;
  gridSize: number;
  items: GridItem[];
  timestamp: number;
}

const MemeEditor: React.FC = () => {
  const router = useRouter();
  const [title, setTitle] = useState<string>('');
  const [gridSize, setGridSize] = useState<number>(2); // 默认2x2网格
  const [gridItems, setGridItems] = useState<GridItem[]>(
    Array(4).fill(null).map(() => ({ id: uuidv4(), imageUrl: null }))
  );
  const memeRef = useRef<HTMLDivElement>(null);

  // 更新网格大小
  const updateGridSize = (size: number) => {
    setGridSize(size);
    const itemCount = size * size;
    setGridItems(
      Array(itemCount).fill(null).map((_, index) => {
        // 保留现有项或创建新项
        return index < gridItems.length 
          ? gridItems[index] 
          : { id: uuidv4(), imageUrl: null };
      }).slice(0, itemCount)
    );
  };

  // 处理图片上传
  const handleImageUpload = (id: string, imageUrl: string) => {
    setGridItems(
      gridItems.map(item => 
        item.id === id ? { ...item, imageUrl } : item
      )
    );
  };

  // 生成并保存梗图
  const generateMeme = async () => {
    if (!memeRef.current || !title) return;

    try {
      const canvas = await html2canvas(memeRef.current);
      const imageUrl = canvas.toDataURL("image/png");
      
      // 创建唯一ID
      const memeId = uuidv4();
      
      // 保存梗图数据（这里使用localStorage，实际项目可能使用数据库）
      const memeData: MemeData = {
        id: memeId,
        title,
        gridSize,
        items: gridItems,
        timestamp: Date.now(),
      };
      
      // 保存到localStorage
      const memesData = localStorage.getItem('memes') 
        ? JSON.parse(localStorage.getItem('memes') || '{}') 
        : {};
      
      memesData[memeId] = {
        ...memeData,
        imageUrl, // 保存渲染后的图像
      };
      
      localStorage.setItem('memes', JSON.stringify(memesData));
      
      // 导航到分享页面
      router.push(`/meme/${memeId}`);
    } catch (error) {
      console.error('生成梗图失败', error);
    }
  };

  // 下载梗图
  const downloadMeme = async () => {
    if (!memeRef.current) return;
    
    try {
      const canvas = await html2canvas(memeRef.current);
      const url = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.download = `${title.replace(/\s+/g, '-').toLowerCase() || 'starter-pack'}.png`;
      link.href = url;
      link.click();
    } catch (error) {
      console.error('下载梗图失败', error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
          Meme 标题
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="例如：The Coffee Addict Starter Pack"
          className="w-full p-2 border border-gray-300 rounded-md"
        />
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          选择网格大小
        </label>
        <div className="flex space-x-4">
          <button
            onClick={() => updateGridSize(2)}
            className={`px-4 py-2 border rounded ${
              gridSize === 2 ? 'bg-black text-white' : 'bg-white text-black'
            }`}
          >
            2 x 2
          </button>
          <button
            onClick={() => updateGridSize(3)}
            className={`px-4 py-2 border rounded ${
              gridSize === 3 ? 'bg-black text-white' : 'bg-white text-black'
            }`}
          >
            3 x 3
          </button>
        </div>
      </div>

      <div className="mb-8">
        <div 
          ref={memeRef}
          className="bg-white border-2 border-black p-4 max-w-3xl mx-auto"
        >
          {title && (
            <h2 className="text-2xl font-bold text-center mb-4">{title}</h2>
          )}
          
          <div 
            className="grid gap-4" 
            style={{ 
              gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
            }}
          >
            {gridItems.map((item) => (
              <div 
                key={item.id}
                className="aspect-square border border-black bg-gray-100 overflow-hidden"
              >
                <ImageUploader 
                  imageUrl={item.imageUrl} 
                  onImageUpload={(url) => handleImageUpload(item.id, url)} 
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={downloadMeme}
          disabled={gridItems.some(item => !item.imageUrl) || !title}
          className="px-6 py-2 bg-blue-600 text-white rounded disabled:bg-gray-400"
        >
          下载梗图
        </button>
        <button
          onClick={generateMeme}
          disabled={gridItems.some(item => !item.imageUrl) || !title}
          className="px-6 py-2 bg-green-600 text-white rounded disabled:bg-gray-400"
        >
          生成并分享
        </button>
      </div>
    </div>
  );
};

export default MemeEditor; 