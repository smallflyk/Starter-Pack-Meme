# Starter Pack Meme 生成器

这是一个简单的 Starter Pack Meme 生成网站，使用 Next.js 和 Tailwind CSS 构建。

## 功能

- 选择 2x2 或 3x3 网格布局
- 上传图片填充网格
- 添加标题文本
- 生成并下载 Meme 图片
- 分享 Meme 链接

## 项目结构

- `/` - 首页，介绍产品并提供"立即制作"按钮
- `/create` - 编辑器页面，用于创建 Meme
- `/meme/[id]` - 分享页面，展示生成的 Meme

## 开发

### 安装依赖

```
npm install
```

### 运行开发服务器

```
npm run dev
```

### 构建项目

```
npm run build
```

### 运行生产版本

```
npm run start
```

## 技术栈

- Next.js - React 框架
- Tailwind CSS - 样式框架
- html2canvas - 用于将 DOM 元素转换为图像
- UUID - 生成唯一 ID 